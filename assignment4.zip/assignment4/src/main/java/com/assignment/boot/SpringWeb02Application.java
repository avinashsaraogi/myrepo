package com.assignment.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWeb02Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringWeb02Application.class, args);
	}

}

