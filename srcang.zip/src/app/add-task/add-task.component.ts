import { Component, OnInit } from '@angular/core';
import { Task } from '../shared/task.model';
import { TaskService } from '../shared/task.service';
import { NgForm } from '@angular/forms';
import * as moment from 'moment';



export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
 
@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
  
})
export class AddTaskComponent implements OnInit {
    formData:Task;
    parenttaskList:Task[] = [];
    isValid : boolean = true;    
  
  constructor(
    private taskService:TaskService,
  ) { }

  ngOnInit() {
    this.taskService.getTaskList().then(res => this.parenttaskList = res as Task[]);
   // this.taskService.getTaskList().subscribe(res => this.parenttaskList = res,
    //  error => this.errorMsg = error);
    this.resetForm();
  }

  onSubmit(form:NgForm){
    this.formData.startDate = moment(this.formData.startDate).format('YYYY-MM-DD');
    this.formData.endDate = moment(this.formData.endDate).format('YYYY-MM-DD');
    if(this.validateForm(form.value)){
      this.taskService.saveTask(this.formData).subscribe(res => {
      this.resetForm();
    });
  }
}

  validateForm(formData:Task){
    this.isValid = true;
    if(formData.taskName == ''){
      this.isValid = false;
    }else if(formData.priority == 0){
      this.isValid = false;
    }else if(formData.startDate.toString() == ''){
      this.isValid = false;
    }else if(formData.endDate.toString() == ''){
      this.isValid = false;
    }
    return this.isValid;
  }

  resetForm(form?:NgForm){
    if(form = null)
    form.resetForm();
    this.formData={
    taskId :null,
    taskName :'',
    priority :0,
    parentTask: new Task(),
    startDate : new Date,
    endDate : new Date,
    status : 0,
    };

}
}
