import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Task } from '../shared/task.model';
import { TaskService } from '../shared/task.service';
import { NgForm } from '@angular/forms';
import * as moment from 'moment';


@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {
  formData:Task;
  isValid : boolean = true;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data : Task,
    public dialogRef:MatDialogRef<EditTaskComponent>,
    private taskService:TaskService
  ) { }

  ngOnInit() {
    if(this.data != null){
      this.formData = this.data;
    }
    
  }

  onSubmit(form:NgForm){
      this.formData.startDate = moment(this.formData.startDate).format('YYYY-MM-DD');
      this.formData.endDate = moment(this.formData.endDate).format('YYYY-MM-DD');
      if(this.validateForm(form.value)){
      this.taskService.updateTask(this.formData.taskId,this.formData);
      this.closeDialog();
      }
    }
  
  closeDialog(): void {
    this.dialogRef.close();
  }

  validateForm(formData:Task){
    this.isValid = true;
    if(formData.taskName == ''){
      this.isValid = false;
    }else if(formData.priority == 0){
      this.isValid = false;
    }else if(formData.startDate.toString() == ''){
      this.isValid = false;
    }else if(formData.endDate.toString() == ''){
      this.isValid = false;
    }
    return this.isValid;
  }


}
