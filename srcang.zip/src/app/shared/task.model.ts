
export class Task {
    taskId :number;
    taskName :string;
    priority :number;
    parentTask:Task;
    startDate : any;
    endDate : any;
    status : number;
}
