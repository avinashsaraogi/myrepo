import { Injectable } from '@angular/core';
import { Task } from './task.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  //formData:Task = new Task();
  taskList:Task[] = new Array();

  constructor(private http:HttpClient) { }

  getTaskList(){
    return this.http.get(environment.apiURL+'/task').toPromise();
  }
  saveTask(formData:Task){
    return this.http.post(environment.apiURL+'/task',formData);
  }
  updateTask(id:number,formData:Task){
    return this.http.put(environment.apiURL+'/task'+'/'+id,formData).toPromise();
  }
  }
