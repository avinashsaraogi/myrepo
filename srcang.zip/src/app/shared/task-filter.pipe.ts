import { PipeTransform, Pipe } from '@angular/core';
import { Task } from './task.model';
import * as moment from 'moment';


@Pipe({
    name: 'taskFilter',
})

export class TaskFilterPipe implements PipeTransform{
    transform(tasks:Task[],
        taskNameSearch: string,
        parentTaskNameSearch: string,
        priorityFromSearch: string,
        priorityToSearch: string,
        startDateSearch: string,
        endDateSearch: string
        ) : Task[] {
        
        if(!tasks) {
            return tasks;
        }
        if(taskNameSearch != ""){
            tasks = [...tasks.filter(task => 
                task.taskName.toLowerCase().includes(taskNameSearch.toLowerCase()))];
        }
        if(parentTaskNameSearch != "" ){
            tasks = [...tasks.filter(task => 
                task.parentTask.taskName.toLowerCase().includes(parentTaskNameSearch.toLowerCase()))];
        }
        if(priorityFromSearch != ""){
            tasks = [...tasks.filter(task => 
                task.priority >= Number(priorityFromSearch.toLowerCase()))];
        }
        if(priorityToSearch != ""){
            //priorityToSearch = priorityToSearch.toLowerCase();
            tasks = [...tasks.filter(task => 
                task.priority <= Number(priorityToSearch.toLowerCase()))];
        }
        if(startDateSearch != ""){
            tasks = [...tasks.filter(task => 
                new Date(task.startDate) >= new Date(startDateSearch))];
                
        }
        if(endDateSearch != ""){
           tasks = [...tasks.filter(task => 
            new Date(task.endDate) <= new Date(endDateSearch))];
        }
         return tasks;
    }
}
