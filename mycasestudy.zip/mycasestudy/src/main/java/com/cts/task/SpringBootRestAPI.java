package com.cts.task;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 

@SpringBootApplication
public class SpringBootRestAPI {
	public static void main(String[] args) {
        SpringApplication.run(SpringBootRestAPI.class, args);
    }
}
